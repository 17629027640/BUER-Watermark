const app = getApp()
const cloud = wx.cloud
const db = cloud.database()
const userCollection = 'watermark_user' //用户表

Page({
    data: {
        //用户信息
        userInfo: {},
        //是否已经授权
        hasUserInfo: '',
        //是否可以发起授权
        canIUseGetUserProfile: '',
        //使用天数
        daysCount: 1,
        //视频总数,total
        videosCount: {},
        //图片总数,total
        imagesCount: {},
        //列表
        mainList: [{
            icon: '/icons/mainList/video.png',
            title: '视频记录'
        },
        {
            icon: '/icons/mainList/images.png',
            title: '图片记录'
        },
        {
            icon: '/icons/mainList/delete.png',
            title: '清除记录'
        },
        {
            icon: '/icons/mainList/about.png',
            title: '关于我们'
        },

        ]
    },
    //页面加载后获取用户状态
    onLoad() {
        let _this = this
        _this.getUserState()
    },
    //下拉刷新，重新获取用户状态
    async onPullDownRefresh() {
        let _this = this
        await _this.getUserState()
        wx.stopPullDownRefresh()
    },
    //判断用户是否授权登录
    async getUserState() {
        let _this = this
        let userState = await db.collection(userCollection)
            .where({
                _openid: '{openid}'
            }).get()
        console.log('判断用户是否授权登录======>');
        if (userState.data.length == 0) {
            console.log('用户未授权', false);
            _this.setData({
                hasUserInfo: false,
                canIUseGetUserProfile: true,
            })
            wx.hideLoading()
        } else {
            wx.showLoading({
                title: '加载中...',
                mask: true
            })
            console.log('用户已授权', true);
            let startTile = userState.data[0]._createTime
            let endTime = new Date().getTime()
            let days = parseInt((endTime - startTile) / (1000 * 60 * 60 * 24) + 1)
            console.log('加载用户数据======>',userState);
            _this.setData({
                hasUserInfo: true,
                canIUseGetUserProfile: false,
                daysCount: days,
                videosCount: (await db.collection('watermark_main').where({
                    // _openid: '{openid}',
                    type: 'video'
                }).count()).total,
                imagesCount: (await db.collection('watermark_main').where({
                    // _openid: '{openid}',
                    type: 'images'
                }).count()).total,
                'userInfo.avatarUrl': userState.data[0].avatarUrl,
                'userInfo.nickName': userState.data[0].nickName,
                'userInfo._openid': userState.data[0]._openid
            })
            //更新数据库
            await cloud.database().collection('watermark_user')
                .where({
                    _openid: '{openid}'
                })
                .update({
                    data: {
                        imageCount: _this.data.imagesCount,
                        videoCount: _this.data.videosCount
                    }
                })
            app.globalData.openid = userState.data[0]._openid
            wx.hideLoading()
            console.log('用户数据加载完成======>');
        }
    },

    //授权用户信息
    getUserProfile() {
        let _this = this
        // 推荐使用wx.getUserProfile获取用户信息，开发者每次通过该接口获取用户个人信息均需用户确认
        wx.getUserProfile({
            desc: '用于完善会员资料', // 声明获取用户个人信息后的用途，后续会展示在弹窗中，请谨慎填写
            success: (res) => {
                //调用云函数获取openid
                cloud.callFunction({
                    name: 'watermark_login',
                    data: {
                        nickName: res.userInfo.nickName,
                        avatarUrl: res.userInfo.avatarUrl
                    },
                    success: res => {
                        app.globalData.openid = res.result.OPENID
                    }
                })
                console.log("登录成功", res.userInfo);
                _this.setData({
                    userInfo: res.userInfo,
                    hasUserInfo: true,
                    canIUseGetUserProfile: false,
                    daysCount: 1,
                    videosCount: 0,
                    imagesCount: 0,
                })
                // _this.getUserState()

                wx.showToast({
                    title: '登录成功',
                    icon: 'success'
                })
            }
        })
    },
    days() {
        wx.showToast({
            title: '感谢你的一路陪伴 ！',
            icon: 'none'
        })
    },
    video() {
        this.mainNav({
            currentTarget: {
                id: 0
            }
        })
    },
    images() {
        this.mainNav({
            currentTarget: {
                id: 1
            }
        })
    },
    // mainList点击事件
    async mainNav(e) {
        let _this = this
        let navIndex = e.currentTarget.id
        switch (parseInt(navIndex)) {
            case 0:
                //视频记录
                console.log('开始跳转视频记录======>');
                wx.navigateTo({
                    url: '../../pages/record/index?type=video'
                })
                break;
            case 1:
                //图片记录
                console.log('开始跳转图片记录======>');
                wx.navigateTo({
                    url: '../../pages/record/index?type=images'
                })
                break;
            case 2:
                //清除数据
                wx.showModal({
                    title: '提示',
                    content: '这将清除所有数据，是否继续',
                    success(res) {
                        if (res.confirm) {
                            console.log('用户点击确定')
                            wx.showLoading({
                                title: '请稍等...',
                                mask: true
                            })
                            cloud.callFunction({
                                name: 'watermark_personal',
                                data: {
                                    type: 'delete'
                                }
                            }).then(res => {
                                console.log(res);
                                wx.hideLoading()
                                if (res.result.remove == 'ok') {
                                    wx.showToast({
                                        title: '清除成功',
                                        icon: 'success'
                                    })
                                    _this.setData({
                                        videosCount: 0,
                                        imagesCount: 0
                                    })
                                }
                                if (res.result.remove == 'nodata') {
                                    wx.showToast({
                                        title: '暂无数据',
                                        icon: 'error'
                                    })
                                }
                            }).catch(err => {
                                console.log(err);
                                wx.showToast({
                                    title: '清除失败！',
                                    icon: 'error'
                                })
                            })
                        } else if (res.cancel) {
                            console.log('用户点击取消')
                        }
                    }
                })
                break;
            case 3:
                //关于我们
                wx.showToast({
                    icon: 'none',
                    title: 'BUERTEAM 丨 2.22.6',
                })
                break;
        }
    },
    handleContact(e){
       console.log('handleContact===>联系我们'); 
    }
})