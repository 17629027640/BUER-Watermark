let _this = null
const cloud = wx.cloud //初始化云开发
const db = cloud.database() //初始化云开发数据库
const userCollection = 'watermark_user' //用户表

Page({
    data: {
        state: {
            displayState: "none",
            video: false,
            images: false,
            type: ''
        },
        workInfo: {
            authorNickname: '',
            authorUID: '',
            copywriting: ''
        },
        dataList: {
            shareUrl: '',
            fileID: [],
        },
    },
    onLoad: function (e) {
        let _this = this
        //判断是否为被分享的页面
        console.log('判断是否为分享页面======>');
        if (Object.keys(e).length !== 0) {
            console.log("分享页======>'",true);
            console.log('分享带有数据', e);
            let data = JSON.parse(decodeURIComponent(e.data))
            _this.setData(data)
        } else {
            console.log("非分享页======>'",false);
        }
    },

    //获取文本框的值
    myInput(e) {
        let _this = this
        _this.setData({
            'dataList.shareUrl': e.detail.value
        })
        console.log('分享链接', _this.data.dataList.shareUrl);
    },
    //清空文本框
    clear() {
        this.setData({
            'dataList.shareUrl': ''
        })
    },
    //开始解析
    async submitButtom() {
        let _this = this
        console.log('开始解析======>');
        //判断用户是否授权
        console.log('判断当前用户是否授权登录======>');
        let userState = await db.collection(userCollection)
            .where({
                _openid: '{openid}'
            }).get()
        //如果没有授权跳转登录页
        if (userState.data.length == 0) {
            console.log('用户未授权======>', false);
            wx.switchTab({
                url: '/pages/personal/index',
            })
        } else {
            //如果已授权，开始解析
            console.log('用户已授权======>', true);
            wx.showLoading({
                title: '正在解析',
                mask: true
            })
            try {
                console.log('正在解析，请稍后======>');
                //正则取http链接
                _this.setData({
                    'dataList.shareUrl': _this.data.dataList.shareUrl.match(/(https?|http|ftp|file):\/\/[-A-Za-z0-9+&@#/%?=~_|!:,.;]+[-A-Za-z0-9+&@#/%=~_|]/g)[0]
                })
                //调用云函数，并传data为http链接
                let res = await cloud.callFunction({
                    name: 'watermark_main',
                    data: {
                        shareUrl: _this.data.dataList.shareUrl
                    }
                })
                //新解析||读数据库
                if (res.result.code == 0 || res.result.code == 1) {
                    wx.hideLoading()
                    wx.showToast({
                        title: '解析成功',
                        icon: 'success'
                    })
                    //遍历解析的类型
                    switch (res.result.data.type) {
                        //如果解析类型为视频
                        case "video":
                            console.log('视频解析成功！');
                            _this.setData({
                                'state.displayState': 'block',
                                'state.video': true,
                                'state.images': false,
                                'state.type': 'video',
                                'dataList.fileID': res.result.data.videoFileID[0],
                                'workInfo.authorNickname': res.result.data.authorNickname,
                                'workInfo.authorUID': res.result.data.authorUID,
                                'workInfo.copywriting': res.result.data.copywriting,
                            })
                            break;
                        //如果解析类型为图片
                        case "images":
                            console.log('图片解析成功！');
                            _this.setData({
                                'state.displayState': 'block',
                                'state.video': false,
                                'state.images': true,
                                'state.type': 'images',
                                'dataList.fileID': res.result.data.imagesFileID,
                                'workInfo.authorNickname': res.result.data.authorNickname,
                                'workInfo.authorUID': res.result.data.authorUID,
                                'workInfo.copywriting': res.result.data.copywriting,
                            })
                            break;
                    }
                } else {
                    wx.hideLoading()
                    console.log('不支持该链接！');
                    wx.showToast({
                        title: res.result.text,
                        icon: 'error'
                    })
                }
            } catch (err) {
                console.log('解析失败！', err);
                wx.showToast({
                    title: '解析失败',
                    icon: 'error'
                })
            }
        }
    },

    //保存 视频：图片
    async save() {
        let _this = this
        //判断是否相册授权
        console.log('判断是否相册授权======>');
        if (await myAuthorize() === true) {
            console.log(true);
            //判断解析的类型
            console.log('判断保存的类型=====>');
            switch (_this.data.state.type) {
                case "video":
                    console.log('保存的是视频');
                    try {
                        wx.showLoading({
                            title: '正在保存',
                            mask: true
                        })
                        // 从云存储中文件下载到手机端，并返回临时链接。
                        console.log('正在下载文件至本地======>');
                        let tempFilePath = await new Promise(async (resolve, reject) => {
                            wx.cloud.downloadFile({
                                fileID: _this.data.dataList.fileID,
                                success: (res) => res.statusCode === 200 ? resolve(res.tempFilePath) : reject(res),
                                fail: (err) => reject(err)
                            })
                        })
                        //将视频保存至手机相册。
                        console.log('正在将视频保存至相册======>');
                        await new Promise(async (resolve, reject) => {
                            wx.saveVideoToPhotosAlbum({
                                filePath: tempFilePath,
                                success: (res) => resolve(res),
                                fail: (err) => reject(err)
                            })
                            wx.hideLoading()
                            wx.showToast({
                                title: '保存相册成功',
                                icon: 'success'
                            })
                            console.log('保存成功');
                        })

                    } catch (error) {
                        console.warn(error)
                        wx.hideLoading()
                        wx.showToast({
                            title: '保存失败',
                            icon: 'error'
                        })
                        console.log('保存失败');
                    }
                    break;
                case "images":
                    console.log('保存的是图片');
                    try {
                        wx.showLoading({
                            title: '正在保存',
                            mask: true
                        })
                        console.log('正在下载文件至本地======>');
                        let tempFilePath = await wx.cloud.getTempFileURL({
                            fileList: _this.data.dataList.fileID
                        })
                        console.log('正在将图片逐个保存至相册======>');
                        tempFilePath.fileList.forEach(item => {
                            wx.downloadFile({
                                url: item.tempFileURL,
                                success: res => {
                                    wx.saveImageToPhotosAlbum({
                                        filePath: res.tempFilePath,
                                        success: (res) => resolve(res),
                                        fail: (err) => reject(err)
                                    })
                                }
                            })
                        })
                        wx.hideLoading()
                        wx.showToast({
                            title: '保存相册成功',
                            icon: 'success'
                        })
                        console.log('保存成功！');

                    } catch (error) {
                        console.warn(error)
                        wx.hideLoading()
                        wx.showToast({
                            title: '保存失败',
                            icon: 'error'
                        })
                        console.log('保存失败');
                    }
                    break;
            }
        } else {
            console.log(false);
        }
    },
    //点击预览图片
    async clickImg(e) {
        let _this = this
        let imageList = _this.data.dataList.fileID //加载的图片列表
        let clickImageIndex = e.currentTarget.id //当前点击图片的ID
        console.log(`图片共${imageList.length}张，当前点击的是第${parseInt(clickImageIndex) + 1}张`);
        try {
            wx.previewImage({
                current: imageList[clickImageIndex], //当前图片的链接 string
                urls: imageList, //图片列表 array
                showmenu: true //是否显示长菜单 bool
            })
        } catch (error) {
            console.log('图片预览失败', error);
        }

    },

    //分享
    onShareAppMessage: function (o) {
        let _this = this
        //跳转路径
        let shareObj = {
            path: 'pages/index/index',
        }
        //按钮分享
        if (o.from === 'button') {
            let data = JSON.stringify(_this.data)
            switch (_this.data.state.type) {
                case "video":
                    shareObj.title = '分享了一个视频：' + _this.data.workInfo.copywriting
                    break;
                case "images":
                    shareObj.title = '分享了一个图集：' + _this.data.workInfo.copywriting
                    break;
            }
            shareObj.path = 'pages/index/index?data=' + encodeURIComponent(data)//传当前页面的data
        }
        //右上角分享
        if (o.from === 'menu') {
            shareObj.imageUrl = '/images/img-share.jpg'
        }
        return shareObj
    }
})

// 获取保存相册权限。
let myAuthorize = async () => {
    return await new Promise((resolve, reject) => {
        wx.authorize({
            scope: 'scope.writePhotosAlbum',
            success: () => resolve(true),
            fail: () => {
                wx.showModal({
                    title: '授权提示',
                    content: '请在设置页面勾选“相册”权限',
                    showCancel: false,
                    complete: () => {
                        // 若第一次授权被拒绝后，弹出提示，让用户自己在设置页授权。（wx.authorize仅在首次会弹出授权）
                        wx.openSetting({
                            complete: resolve(false)
                        })
                    }
                })
            }
        })
    })
}