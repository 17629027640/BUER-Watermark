//初始化微信云开发
const cloud = wx.cloud
//初始化云数据
const db = cloud.database()



const _ = db.command
const douyin_watermark_collection = 'watermark_main' //记录表
let PageSize = 20   //每次加载的数量
let CurrentPage = 0    //第CurrentPage请求需要跳转的CurrentPage数量
let type    //接收跳转来源，video、images

Page({
    data: {
        index: 0,//当前所操作的item
        moveDistance: 0,//移动距离
        title: '',//标题
        type: {//显示的类型，true为显示、false为隐藏
            video: false,
            image: false,
            type: ''
        },
        contentListData: []//列表

    },
    async onLoad(e) {
        let _this = this
        _this.setData({
            'type.type': e.type//设置类型为跳转时携带的参数，video、images
        })
        console.log('跳转来源：', _this.data.type.type);
        switch (_this.data.type.type) {
            //从视频跳转过来
            case "video":
                CurrentPage = 0//设置从CurrentPage开始加载
                wx.showLoading({
                    title: '加载中...',
                })
                _this.setData({
                    title: '视频记录，左滑即可删除对应记录',
                    "type.video": true,
                    "type.image": false,
                })
                _this.getData(_this.data.type.type)
                break;
            //从图片跳转过来
            case "images":
                CurrentPage = 0//设置从CurrentPage开始加载
                wx.showLoading({
                    title: '加载中...',
                })
                _this.setData({
                    title: '图片记录，左滑即可删除对应记录',
                    "type.video": false,
                    "type.image": true,
                })
                _this.getData(_this.data.type.type)
                break;
        }
    },

    //加载数据
    async getData(e) {
        let _this = this;
        db.collection(douyin_watermark_collection)
            .where({
                // _openid: "{openid}",//当前登录的微信用户
                type: e
            })
            .orderBy('_creatTime', 'desc')//时间为降序，升序asc、降序desc
            .skip(CurrentPage * PageSize)
            .limit(PageSize)
            .get()
            .then(res => {
                wx.hideLoading()
                wx.stopPullDownRefresh() //停止下拉刷新
                if (res.data.length != 0) {
                    console.log(e + "数据请求成功", res.data)
                    CurrentPage++
                    let list = _this.data.contentListData.concat(res.data)
                    _this.setData({
                        contentListData: list
                    })
                }
                else {
                    wx.showToast({
                        title: '加载完成，暂无更多记录',
                        icon: 'none',
                        duration: 3000
                    })
                }

            })
            .catch(err => {
                console.log('请求失败');
            })
    },
    //点开对应item跳转show页面
    itemInfo(e) {
        let _this = this
        let itemIndex = parseInt(e.currentTarget.id)
        //传当前点击的item所对应的data
        let data = JSON.stringify(_this.data.contentListData[itemIndex])
        wx.navigateTo({
            url: '../../pages/show/index?data=' + encodeURIComponent(data),
        })
    },

    //页面上拉触底
    onReachBottom: function () {
        console.log("上拉触底事件")
        let _this = this
        wx.showLoading({
            title: '加载中...',
            mask: 'true'
        })
        _this.getData(_this.data.type.type)
    },

    //下拉刷新
    onPullDownRefresh: function () {
        console.log('下拉刷新事件');
        wx.showLoading({
            title: '加载中...',
        })
        let _this = this
        CurrentPage = 0
        setTimeout(function () {
            _this.setData({
                contentListData: []
            })
            _this.getData(_this.data.type.type)
        }, 1000)

    },
    //触摸开始
    touchStart(e) {
        let list = this.data.contentListData
        list[this.data.index].isMove = false
        this.setData({
            index: e.currentTarget.dataset.index,
            moveDistance: e.changedTouches[0].pageX,
            contentListData: list
        })
    },
    //触摸移动
    touchMove(e) {
        //列表数组
        let list = this.data.contentListData
        //移动距离，移动距离 = 触摸的位置 - 移动后的触摸位置
        let move = this.data.moveDistance - e.changedTouches[0].pageX
        //第index项
        list[this.data.index].isMove = move > 100 ? true : false
        this.setData({
            contentListData: list
        })
    },
    //删除
    delete(e) {
        let index = e.currentTarget.dataset.index
        let arr = this.data.contentListData
        wx.showLoading({
            title: '删除中...',
        })
        //删除数据库
        let doc = arr[index]._id
        console.log('删除数据库');
        db.collection(douyin_watermark_collection).doc(doc)
            .remove().then(res => {
                console.log(res);
                console.log('数据库删除成功，开始删除云存储');
                //删除云存储
                let fileList = arr[index].imagesFileID.length != 0 ? arr[index].imagesFileID : arr[index].videoFileID
                cloud.deleteFile({
                    fileList: fileList
                }).then(res => {
                    console.log(res);
                    console.log('云存储删除成功！');
                    wx.hideLoading()
                    arr.splice(index, 1)
                    this.setData({
                        contentListData: arr
                    })
                    wx.showToast({
                        title: '删除成功',
                    })
                })
            })
    }
})