let _this = null
const cloud = wx.cloud
const db = cloud.database()
const userCollection = 'watermark_user' //用户表
let data

Page({
    data: {
        state: {
            displayState: "none",
            video: false,
            images: false,
            type: ''
        },
        workInfo: {
            authorNickname: '',
            authorUID: '',
            copywriting: ''
        },
        dataList: {
            shareUrl: '',
            fileID: [],
        },
    },
    onLoad: function (e) {
        let _this = this
        data = JSON.parse(decodeURIComponent(e.data))
        console.log('页面加载数据', data);
        if (data.type == 'video') {
            _this.setData({
                'state.displayState': 'block',
                'state.video': true,
                'state.images': false,
                'state.type': 'video',
                'dataList.fileID': data.videoFileID[0],
                'workInfo.authorNickname': data.authorNickname,
                'workInfo.authorUID': data.authorUID,
                'workInfo.copywriting': data.copywriting,
            })
        }
        else {
            _this.setData({
                'state.displayState': 'block',
                'state.video': false,
                'state.images': true,
                'state.type': 'images',
                'dataList.fileID': data.imagesFileID,
                'workInfo.authorNickname': data.authorNickname,
                'workInfo.authorUID': data.authorUID,
                'workInfo.copywriting': data.copywriting,
            })
        }
    },

    //保存 视频：图片
    async save() {
        let _this = this
        //判断是否相册授权
        console.log('判断是否相册授权======>');
        if (await myAuthorize() === true) {
            console.log(true);
            //判断解析的类型
            console.log('判断保存的类型=====>');
            switch (_this.data.state.type) {
                case "video":
                    console.log('保存的是视频');
                    try {
                        wx.showLoading({
                            title: '正在保存',
                            mask: true
                        })
                        // 从云存储获取临时链接。
                        console.log('正在下载文件至本地======>');
                        let tempFilePath = await new Promise(async (resolve, reject) => {
                            wx.cloud.downloadFile({
                                fileID: _this.data.dataList.fileID,
                                success: (res) => res.statusCode === 200 ? resolve(res.tempFilePath) : reject(res),
                                fail: (err) => reject(err)
                            })
                        })
                        //保存至手机相册。
                        console.log('正在将文件保存至相册======>');
                        await new Promise(async (resolve, reject) => {
                            wx.saveVideoToPhotosAlbum({
                                filePath: tempFilePath,
                                success: (res) => resolve(res),
                                fail: (err) => reject(err)
                            })
                            wx.hideLoading()
                            wx.showToast({
                                title: '保存相册成功',
                                icon: 'success'
                            })
                            console.log('保存成功');
                        })

                    } catch (error) {
                        console.warn(error)
                        wx.hideLoading()
                        wx.showToast({
                            title: '保存失败',
                            icon: 'error'
                        })
                        console.log('保存失败');
                    }
                    break;
                case "images":
                    console.log('保存的是图片');
                    try {
                        wx.showLoading({
                            title: '正在保存',
                            mask: true
                        })
                        console.log('正在下载文件至本地======>');
                        let tempFilePath = await wx.cloud.getTempFileURL({
                            fileList: _this.data.dataList.fileID
                        })
                        console.log('正在将图片逐个保存至相册======>');
                        tempFilePath.fileList.forEach(item => {
                            wx.downloadFile({
                                url: item.tempFileURL,
                                success: res => {
                                    wx.saveImageToPhotosAlbum({
                                        filePath: res.tempFilePath
                                    })
                                },
                            })
                        })
                        wx.hideLoading()
                        wx.showToast({
                            title: '保存相册成功',
                            icon: 'success'
                        })
                        console.log('保存成功！');

                    } catch (error) {
                        console.warn(error)
                        wx.hideLoading()
                        wx.showToast({
                            title: '保存失败',
                            icon: 'error'
                        })
                        console.log('保存失败');
                    }
                    break;
            }
        } else {
            console.log(false);
        }
    },
    //点击预览图片
    async clickImg(e) {
        let _this = this
        let imageList = _this.data.dataList.fileID //加载的图片列表
        let clickImageIndex = e.currentTarget.id //当前点击图片的ID
        console.log(`图片共${imageList.length}张，当前点击的是第${parseInt(clickImageIndex) + 1}张`);
        try {
            wx.previewImage({
                current: imageList[clickImageIndex], //当前图片的链接 string
                urls: imageList, //图片列表 array
                showmenu: true //是否显示长菜单 bool
            })
        } catch (error) {
            console.log('图片预览失败', error);
        }

    },

    //分享
    onShareAppMessage: function (o) {
        let _this = this
        //跳转路径
        let shareObj = {
            path: 'pages/index/index',
        }
        //按钮分享
        if (o.from === 'button') {
            switch (_this.data.state.type) {
                case "video":
                    shareObj.title = '分享了一个视频：' + _this.data.workInfo.copywriting
                    break;
                case "images":
                    shareObj.title = '分享了一个图集：' + _this.data.workInfo.copywriting
                    break;
            }
            shareObj.path = 'pages/show/index?data=' + encodeURIComponent(JSON.stringify(data))//传当前页面的data
        }
        //右上角分享
        if (o.from === 'menu') {
            shareObj.imageUrl = '/images/img-share.jpg'
        }
        return shareObj
    }
})

// 获取保存相册权限。
let myAuthorize = async () => {
    return await new Promise((resolve, reject) => {
        wx.authorize({
            scope: 'scope.writePhotosAlbum',
            success: () => resolve(true),
            fail: () => {
                wx.showModal({
                    title: '授权提示',
                    content: '请在设置页面勾选“相册”权限',
                    showCancel: false,
                    complete: () => {
                        // 若第一次授权被拒绝后，弹出提示，让用户自己在设置页授权。（wx.authorize仅在首次会弹出授权）
                        wx.openSetting({
                            complete: resolve(false)
                        })
                    }
                })
            }
        })
    })
}