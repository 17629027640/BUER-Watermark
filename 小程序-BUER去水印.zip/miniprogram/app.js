App({
    onLaunch: async function () {
        if (!wx.cloud) {
            console.error('请使用 2.2.3 或以上的基础库以使用云能力');
        } else {
            wx.cloud.init({
                //这里填入环境id
                env: 'watermark-official-2d0li0ecbf398',
                traceUser: true,
            });
        }
    },
    //全局data
    globalData: {
        hasUserInfo: '',
        canIUseGetUserProfile: '',
        openid:'123'
    },
});